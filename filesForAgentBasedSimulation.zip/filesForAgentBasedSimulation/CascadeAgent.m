/* CascadeAgent.m

Copyright (C) 2020-2025,  Charles Efferson, University of Lausanne. 

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Methods file in Obj-C for agent-based simulation associated with "The evolution of distorted beliefs versus mistaken choices under asymmetric error costs" by Charles Efferson, Ryan McKay, and Ernst Fehr.

*/

#import "CascadeAgent.h"
#import "mt19937ar.h" // For fast Mersenne twister, which you can find at http://www.math.sci.hiroshima-u.ac.jp/~m-mat/MT/MT2002/emt19937ar.html

#import <stdlib.h>

@implementation CascadeAgent
// setters
-(void) setInitProbOne: (double) initOne
{
	initProbOne = initOne;
}

-(void) setUtilZeroZero: (double) u00
{
	utilZeroZero = u00;
}

-(void) setUtilZeroOne: (double) u01
{
	utilZeroOne = u01;
}

-(void) setUtilOneZero: (double) u10
{
	utilOneZero = u10;
}

-(void) setUtilOneOne: (double) u11
{
	utilOneOne = u11;
}

-(void) setPerceivedSignalProbZero: (double) s0
{
	perceivedSignalProbZero = s0;
}

-(void) setPerceivedSignalProbOne: (double) s1
{
	perceivedSignalProbOne = s1;
}

-(void) setActualSignalProbZero: (double) a0
{
	actualSignalProbZero = a0;
}

-(void) setActualSignalProbOne: (double) a1
{
	actualSignalProbOne = a1;
}

-(void) setEnv: (int) e;
{
	env = e;
}

-(void) setPriorOneFirstAgent;		// sets priorOne for an agent who's first in the sequence of decision makers
{
	priorOne = initProbOne;
}

-(void) setPriorOneNotFirstAgent: (CascadeAgent *) laggedAgent;		// sets priorOne for an agent who is not the first agent in the sequence of decision makers
{
	// This model and this method assume that all agent's have the same values for lambda, perceivedSignalProbZero, perceivedSignalProbOne, utilZeroZero, utilZeroOne, utilOneZero, and utilOneOne
	// For this reason we can use the focal agent's values for lambda, perceivedSignalProbZero, perceivedSignalProbOne, utilZeroZero, utilZeroOne, utilOneZero, and utilOneOne in the calculations below instead of the values for the lagged agent
	laggedPriorOne = [laggedAgent priorOne];				// the prior for the lagged agent, also the lagged public belief
	laggedChoice = [laggedAgent choice];					// the observable choice of the lagged agent
	
	laggedUpdatedZeroSignal = (1.0 - perceivedSignalProbOne) * laggedPriorOne / ((1.0 - perceivedSignalProbOne) * laggedPriorOne + perceivedSignalProbZero * (1.0 - laggedPriorOne));	// the lagged agent's updated probability env state is 1 under a 0 private signal
	laggedUpdatedOneSignal = perceivedSignalProbOne * laggedPriorOne / (perceivedSignalProbOne * laggedPriorOne + (1.0 - perceivedSignalProbZero) * (1.0 - laggedPriorOne));			// the lagged agent's updated probability env state is 1 under a 1 private signal
		
	laggedExpUtil00 = laggedUpdatedZeroSignal * utilZeroOne + (1.0 - laggedUpdatedZeroSignal) * utilZeroZero;			// the expected utility for the lagged agent of choosing 0 given a private signal 0
	laggedExpUtil01 = laggedUpdatedOneSignal * utilZeroOne + (1.0 - laggedUpdatedOneSignal) * utilZeroZero;			// the expected utility for the lagged agent of choosing 0 given a private signal 1
	laggedExpUtil10 = laggedUpdatedZeroSignal * utilOneOne + (1.0 - laggedUpdatedZeroSignal) * utilOneZero;			// the expected utility for the lagged agent of choosing 1 given a private signal 0
	laggedExpUtil11 = laggedUpdatedOneSignal * utilOneOne + (1.0 - laggedUpdatedOneSignal) * utilOneZero;				// the expected utility for the lagged agent of choosing 1 given a private signal 1
	
	laggedProbChooseOneGivenZero = (1.0 - perceivedSignalProbZero) * exp(lambda * laggedExpUtil11) / (exp(lambda * laggedExpUtil11) + exp(lambda * laggedExpUtil01)) + perceivedSignalProbZero * exp(lambda * laggedExpUtil10) / (exp(lambda * laggedExpUtil10) + exp(lambda * laggedExpUtil00));	// the ex ante perceived probability the lagged agent would have chosen 1 given that the realized state of the environment is 0
	laggedProbChooseOneGivenOne = perceivedSignalProbOne * exp(lambda * laggedExpUtil11) / (exp(lambda * laggedExpUtil11) + exp(lambda * laggedExpUtil01)) + (1.0 - perceivedSignalProbOne) * exp(lambda * laggedExpUtil10) / (exp(lambda * laggedExpUtil10) + exp(lambda * laggedExpUtil00));		// the ex ante perceived probability the lagged agent would have chosen 1 given that the realized state of the environment is 1
	
	if (laggedChoice == 0)
	{
		double laggedProbChooseZeroGivenZero = 1.0 - laggedProbChooseOneGivenZero;
		double laggedProbChooseZeroGivenOne = 1.0 - laggedProbChooseOneGivenOne;
		
		priorOne = laggedProbChooseZeroGivenOne * laggedPriorOne / (laggedProbChooseZeroGivenOne * laggedPriorOne + laggedProbChooseZeroGivenZero * (1.0 - laggedPriorOne));	// this is the focal agent's prior, which holds after observing the lagged agent's choice 0
	}
	else
	{
		priorOne = laggedProbChooseOneGivenOne * laggedPriorOne / (laggedProbChooseOneGivenOne * laggedPriorOne + laggedProbChooseOneGivenZero * (1.0 - laggedPriorOne));		// this is the focal agent's prior, which holds after observing the lagged agent's choice 1
	}
}
		
-(void) setPrivateSignal
{
	if (env == 0)
	{
		if ((double) 1.0 - genrand_real2() <= actualSignalProbZero)
		{
			privateSignal = 0;
		}
		else
		{
			privateSignal = 1;
		}
	}
	else
	{
		if ((double) 1.0 - genrand_real2() <= actualSignalProbOne)
		{
			privateSignal = 1;
		}
		else
		{
			privateSignal = 0;
		}
	}
}

-(void) setPosteriorOne
{
	if (privateSignal == 0)
	{
		posteriorOne = (1.0 - perceivedSignalProbOne) * priorOne / ((1.0 - perceivedSignalProbOne) * priorOne + perceivedSignalProbZero * (1.0 - priorOne));
	}
	else
	{
		posteriorOne = perceivedSignalProbOne * priorOne / (perceivedSignalProbOne * priorOne + (1.0 - perceivedSignalProbZero) * (1.0 - priorOne));
	}
}

-(void) setLambda: (double) l
{
	lambda = l;
}

-(void) setChoice
{
	if (privateSignal == 0)
	{
		double expUtil00 = posteriorOne * utilZeroOne + (1.0 - posteriorOne) * utilZeroZero;	// expected utility of choosing 0 if observed a 0 signal
		double expUtil10 = posteriorOne * utilOneOne + (1.0 - posteriorOne) * utilOneZero;	// expected utility of choosing 1 if observed a 0 signal
	
		if ((double) 1.0 - genrand_real2() <= exp(lambda * expUtil10) / (exp(lambda * expUtil10) + exp(lambda * expUtil00)))
		{
			choice = 1;
		}
		else
		{
			choice = 0;
		}
	}
	else
	{
		double expUtil01 = posteriorOne * utilZeroOne + (1.0 - posteriorOne) * utilZeroZero;	// expected utility of choosing 0 if observed a 1 signal
		double expUtil11 = posteriorOne * utilOneOne + (1.0 - posteriorOne) * utilOneZero;	// expected utility of choosing 1 if observed a 1 signal
			
		if ((double) 1.0 - genrand_real2() <= exp(lambda * expUtil11) / (exp(lambda * expUtil11) + exp(lambda * expUtil01)))
		{
			choice = 1;
		}
		else
		{
			choice = 0;
		}
	}
}

-(void) setChoiceCorrect
{
	if (choice == env)
	{
		choiceCorrect = 1;
	}
	else
	{
		choiceCorrect = 0;
	}
}

// setters for intermediate variables
-(void) setLaggedPriorOne
{
	laggedPriorOne = -99.9;
}

-(void) setLaggedChoice
{
	laggedChoice = -99;
}

-(void) setLaggedUpdatedZeroSignal
{
	laggedUpdatedZeroSignal = -99.9;
}

-(void) setLaggedUpdatedOneSignal
{
	laggedUpdatedOneSignal = -99.9;
}

-(void) setLaggedExpUtil00
{
	laggedExpUtil00 = -99.9;
}

-(void) setLaggedExpUtil01
{
	laggedExpUtil01 = -99.9;
}

-(void) setLaggedExpUtil10
{
	laggedExpUtil10 = -99.9;
}

-(void) setLaggedExpUtil11
{
	laggedExpUtil11 = -99.9;
}

-(void) setLaggedProbChooseOneGivenZero
{
	laggedProbChooseOneGivenZero = -99.9;
}

-(void) setLaggedProbChooseOneGivenOne
{
	laggedProbChooseOneGivenOne = -99.9;
}

// getters
-(double) initProbOne
{
	return initProbOne;
}

-(double) utilZeroZero
{
	return utilZeroZero;
}

-(double) utilZeroOne
{
	return utilZeroOne;
}

-(double) utilOneZero
{
	return utilOneZero;
}

-(double) utilOneOne
{
	return utilOneOne;
}

-(double) perceivedSignalProbZero
{
	return perceivedSignalProbZero;
}

-(double) perceivedSignalProbOne
{
	return perceivedSignalProbOne;
}

-(double) actualSignalProbZero
{
	return actualSignalProbZero;
}

-(double) actualSignalProbOne
{
	return actualSignalProbOne;
}

-(int) env
{
	return env;
}

-(double) priorOne
{
	return priorOne;
}

-(int) privateSignal
{
	return privateSignal;
}

-(double) posteriorOne
{
	return posteriorOne;
}

-(double) lambda
{
	return lambda;
}

-(int) choice
{
	return choice;
}

-(int) choiceCorrect
{
	return choiceCorrect;
}

// getters for intermediate variables
-(double) laggedPriorOne
{
	return laggedPriorOne;
}

-(int) laggedChoice
{
	return laggedChoice;
}

-(double) laggedUpdatedZeroSignal
{
	return laggedUpdatedZeroSignal;
}

-(double) laggedUpdatedOneSignal
{
	return laggedUpdatedOneSignal;
}

-(double) laggedExpUtil00
{
	return laggedExpUtil00;
}

-(double) laggedExpUtil01
{
	return laggedExpUtil01;
}

-(double) laggedExpUtil10
{
	return laggedExpUtil10;
}

-(double) laggedExpUtil11
{
	return laggedExpUtil11;
}

-(double) laggedProbChooseOneGivenZero
{
	return laggedProbChooseOneGivenZero;
}

-(double) laggedProbChooseOneGivenOne
{
	return laggedProbChooseOneGivenOne;
}

@end
