/* CascadeAgent.h

Copyright (C) 2020-2025,  Charles Efferson, University of Lausanne. 

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Header file in Obj-C for agent-based simulation associated with "The evolution of distorted beliefs versus mistaken choices under asymmetric error costs" by Charles Efferson, Ryan McKay, and Ernst Fehr

To use the simulation, you need to compile the associated files into an executable.
1) Ensure these files are in the working directory: 
	CascadeAgent.h
	CascadeAgent.m 
	main.m 
	mt19937.h, for fast Mersenne twister, which you can find at http://www.math.sci.hiroshima-u.ac.jp/~m-mat/MT/MT2002/emt19937ar.html
	mt19937.m, for fast Mersenne twister, which you can find at http://www.math.sci.hiroshima-u.ac.jp/~m-mat/MT/MT2002/emt19937ar.html
	
2) Install as appropriate gcc (compiler), gsl (GNU Scientific Library), and GNUstep development tools.  For example, using the integrated bash distributed with Windows 10:
	
	sudo apt-get install build-essential
	sudo apt-get install libgsl2
	sudo apt-get install libgsl-dev
	sudo apt-get install gobjc
	sudo apt-get install gnustep-devel

3) In the working directory, compile into an executable named "simulate" as follows for integrated bash distributed with Windows 10:
	gcc $(gnustep-config --objc-flags) $(gsl-config --cflags) *.m  $(gnustep-config --gui-libs) $(gsl-config --libs) -o simulate
	
*/

#import <Foundation/Foundation.h>


@interface CascadeAgent : NSObject 
{
	double initProbOne;				// the ex ante probability that the environment is in state 1, an element of [0,1]
	double utilZeroZero;			// utility value if the agent guesses 0 given the realized environment is 0, any real number
	double utilZeroOne;				// utility value if the agent guesses 0 given the realized environment is 1, any real number
	double utilOneZero;				// utility value if the agent guesses 1 given the realized environment is 0, any real number
	double utilOneOne;				// utility value if the agent guesses 1 given the realized environment is 1, any real number
		
	double perceivedSignalProbZero;			// perceived/subjective probability the private signal indicates 0 if the realized environment is 0
	double perceivedSignalProbOne;			// perceived/subjective probability the private signal indicates 1 if the realized environment is 1
	double actualSignalProbZero;			// actual probability the private signal indicates 0 if the realized environment is 0
	double actualSignalProbOne;				// actual probability the private signal indicates 1 if the realized environment is 1
	
	int env;						// the realized state of the environment
		
	double priorOne;				// the agent's prior probability that the environment is in state 1; this is also the public belief
	int privateSignal;				// the agent's private signal about the state of the environment, an element of {0,1}
	double posteriorOne;			// the agents posterior probability that the environment is in state 1; this belief is private b/c it depends on the private signal
	double lambda;					// the agent's value for lambda, the error rate under the QRE model
	int choice;						// the agent's choice, an element of {0,1}
	int choiceCorrect;				// a dummy indicating if the agent's choice matches the realized environment
	
	// The following are various lagged variables used in the updating process.
	double laggedPriorOne;					// the prior probability of env state 1 for the lagged agent
	int laggedChoice;						// the choice of the lagged agent
	double laggedUpdatedZeroSignal;			// the updated probability that env state is 1 for an agent who receives a private signal 0
	double laggedUpdatedOneSignal;			// the udpated probability that env state is 1 for an agent who receives a private signal 1
	double laggedExpUtil00;					// the expected utility of choosing 0 for the lagged agent who observes private signal 0
	double laggedExpUtil01;					// the expected utility of choosing 0 for the lagged agent who observes private signal 1
	double laggedExpUtil10;					// the expected utility of choosing 1 for the lagged agent who observes private signal 0
	double laggedExpUtil11;					// the expected utility of choosing 1 for the lagged agent who observes private signal 1
	double laggedProbChooseOneGivenZero;	// the probability the lagged agent chooses 1 given the realized env state is 0
	double laggedProbChooseOneGivenOne;		// the probability the lagged agent chooses 1 given the realized env state is 1
}

-(void) setInitProbOne: (double) initOne;
-(void) setUtilZeroZero: (double) u00;
-(void) setUtilZeroOne: (double) u01;
-(void) setUtilOneZero: (double) u10;
-(void) setUtilOneOne: (double) u11;
-(void) setPerceivedSignalProbZero: (double) s0;
-(void) setPerceivedSignalProbOne: (double) s1;
-(void) setActualSignalProbZero: (double) a0;
-(void) setActualSignalProbOne: (double) a1;
-(void) setEnv: (int) e;
-(void) setPriorOneFirstAgent;		// sets priorOne for an agent who's first in the sequence of decision makers
-(void) setPriorOneNotFirstAgent: (CascadeAgent *) laggedAgent;		// sets priorOne for an agent who is not the first agent in the sequence of decision makers
-(void) setPrivateSignal;
-(void) setPosteriorOne;
-(void) setLambda: (double) l;
-(void) setChoice;
-(void) setChoiceCorrect;
-(void) setLaggedPriorOne;
-(void) setLaggedChoice;
-(void) setLaggedUpdatedZeroSignal;
-(void) setLaggedUpdatedOneSignal;
-(void) setLaggedExpUtil00;
-(void) setLaggedExpUtil01;
-(void) setLaggedExpUtil10;
-(void) setLaggedExpUtil11;
-(void) setLaggedProbChooseOneGivenZero;
-(void) setLaggedProbChooseOneGivenOne;

// getters
-(double) initProbOne;
-(double) utilZeroZero;
-(double) utilZeroOne;
-(double) utilOneZero;
-(double) utilOneOne;
-(double) perceivedSignalProbZero;
-(double) perceivedSignalProbOne;
-(double) actualSignalProbZero;
-(double) actualSignalProbOne;
-(int) env;
-(double) priorOne;
-(int) privateSignal;
-(double) posteriorOne;
-(double) lambda;
-(int) choice;
-(int) choiceCorrect;
-(double) laggedPriorOne;
-(int) laggedChoice;
-(double) laggedUpdatedZeroSignal;
-(double) laggedUpdatedOneSignal;
-(double) laggedExpUtil00;
-(double) laggedExpUtil01;
-(double) laggedExpUtil10;
-(double) laggedExpUtil11;
-(double) laggedProbChooseOneGivenZero;
-(double) laggedProbChooseOneGivenOne;

@end
