/* main.m

Copyright (C) 2020-2025,  Charles Efferson, University of Lausanne. 

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Main file in Obj-C for agent-based simulation associated with "The evolution of distorted beliefs versus mistaken choices under asymmetric error costs" by Charles Efferson, Ryan McKay, and Ernst Fehr.

*/

#import "CascadeAgent.h"
#import "mt19937ar.h" // For fast Mersenne twister, which you can find at http://www.math.sci.hiroshima-u.ac.jp/~m-mat/MT/MT2002/emt19937ar.html

int main (int argc, const char *argv[])  {

	init_genrand((unsigned)time(NULL));		// seed Mersenne Twister
	
	// acquire needed parameters
	
	int numAgents = atoi(argv[1]); // num agents in sequence/population
	int numSims = atoi(argv[2]); // num independent simulations per parameter combination
	
	double initProbOne = atof(argv[3]); // ex ante prob in [0,1] that env is in state 1
	
	double utilZeroZero = atof(argv[4]); // utility of guessing env is state 0 if realized state is 0
	double utilZeroOne = atof(argv[5]); // utility of guessing env is state 0 if realized state is 1
	double utilOneZero = atof(argv[6]); // utlity of guessing env is state 1 if realized state is 0
	double utilOneOne = atof(argv[7]); // utility of guessing env is state 1 if realized state is 1
	
	double perceivedSignalProbZero = atof(argv[8]); // perceived (subjective) prob the private signal indicates 0 if realized state is 0, e.g. \hat{q}
	double perceivedSignalProbOne = atof(argv[9]); // perceived (subjective) prob the private signal indicates 1 if realized state is 1, e.g. \hat{q}
	
	double actualSignalProbZero = atof(argv[10]); // actual prob the private signal indicates 0 if realized state is 0, e.g. \hat{q} - alpha
	double actualSignalProbOne = atof(argv[11]); // actual prob the private signal indicates 1 if realized state is 1, e.g. \hat{q} + beta
	
	double lambda = atof(argv[12]); // logit sensitivity parameter for all agents
	
	int disaggData = atoi(argv[13]); // record/print disaggregated data
	int aggData = atoi(argv[14]); // record/print aggregated data
	int finalPeriodData = atoi(argv[15]); // record/print data from the final period of each sequence/simulation
	
	int t;		// index for agent in sequence
	int i;		// index for simulation
		
	FILE *disaggOutput = fopen(argv[16],"w");		// output file for disaggregated data
	FILE *aggOutput = fopen(argv[17],"w");	// output file
	FILE *finalPeriodOutput = fopen(argv[18],"w");	// output file for recording data from the final period of each simulation
	
	// POTENTIALLY REARRANGE THE OUTPUT IN THESE FILES, E.G. MAYBE REMOVE PARAMETER VALUES B/C THEY'LL BE INCLUDED IN THE FILE NAMES.
	if (disaggData == 1)
	{
		// the following is disaggregated output
		fprintf(disaggOutput,"sim	period	priorOne	privateSignal	posteriorOne	choice	env\n");
	}
	
	if (aggData == 1)
	{
		// The following is aggregated output
		fprintf(aggOutput,"period	meanPriorOneGivenZero	meanPriorOneGivenOne	propSimsChoiceCorrectGivenZero	propSimsChoiceCorrectGivenOne	meanCumPropCorrectGivenZero	meanCumPropCorrectGivenOne	numSimsEnvZero	numSimsEnvOne	numSims\n");
	}
	
	if (finalPeriodData == 1)
	{
		// the following is final period output
		fprintf(finalPeriodOutput,"sim	period	priorOne	privateSignal	posteriorOne	choice	env\n");
	}
	
	
	// initialize agents
	CascadeAgent *agent[numAgents];
	for (t = 0; t < numAgents; t++)
	{
		agent[t] = [[CascadeAgent alloc] init];
		[agent[t] setInitProbOne: initProbOne];
		[agent[t] setUtilZeroZero: utilZeroZero];
		[agent[t] setUtilZeroOne: utilZeroOne];
		[agent[t] setUtilOneZero: utilOneZero];
		[agent[t] setUtilOneOne: utilOneOne];
		[agent[t] setPerceivedSignalProbZero: perceivedSignalProbZero];
		[agent[t] setPerceivedSignalProbOne: perceivedSignalProbOne];
		[agent[t] setActualSignalProbZero: actualSignalProbZero];
		[agent[t] setActualSignalProbOne: actualSignalProbOne];
		[agent[t] setLambda: lambda];
	}
	
	// initialize the array for recording the number of correct choices over simulations when env = 0
	int sumChoiceCorrectGivenZero[numAgents];
	
	// initialize the array for recording the number of correct choices over simulations when env = 1
	int sumChoiceCorrectGivenOne[numAgents];
	
	// initialize the array for recording the sum over simulations of the cumulative (through period t) proportion of correct choices when env = 0
	double sumCumulativePropCorrectGivenZero[numAgents];
	
	// initialize the array for recording the sum over simulations of the cumulative (through period t) proportion of correct choices when env = 1
	double sumCumulativePropCorrectGivenOne[numAgents];
	
	// initialize the array for recording the cumulative number of correct choices for a single focal simulation
	int cumulativeNumCorrectThisSim[numAgents];
	
	// initialize the array for recording the cumulative proportion of correct choices for a single focal simulation
	double cumulativePropCorrectThisSim[numAgents];
	
	// initialize the array for recording the sum of priorOne values over simulations for each agent in sequence when env = 0
	double sumPriorOneGivenZero[numAgents];
	
	// initialize the array for recording the sum of priorOne values over simulations for each agent in sequence when env = 1
	double sumPriorOneGivenOne[numAgents];
	
	// initialize quantity for recording the number of sequences for which env = 0
	int sumEnvZero = 0;
	
	// same for env = 1
	int sumEnvOne = 0;	
	
	for (t = 0; t < numAgents; t++)
	{
		sumChoiceCorrectGivenZero[t] = 0;
		sumChoiceCorrectGivenOne[t] = 0;
		sumCumulativePropCorrectGivenZero[t] = 0.0;
		sumCumulativePropCorrectGivenOne[t] = 0.0;
		sumPriorOneGivenZero[t] = 0.0;
		sumPriorOneGivenOne[t] = 0.0;
	}
	
	for (i = 0; i < numSims; i++)
	{
		// set realized environment
		if (genrand_real1() <= initProbOne)	// realized environment is 1
		{
			sumEnvOne += 1;
			
			for (t = 0; t < numAgents; t++)
			{
				[agent[t] setEnv: 1];
			}
		}
		else	// realized environment is 0
		{
			sumEnvZero += 1;
			
			for (t = 0; t < numAgents; t++)
			{
				[agent[t] setEnv: 0];
			}
		}
		
		// set priors, private signals
		for (t = 0; t < numAgents; t++)
		{
			[agent[t] setLaggedPriorOne];
			[agent[t] setLaggedChoice];
			[agent[t] setLaggedUpdatedZeroSignal];
			[agent[t] setLaggedUpdatedOneSignal];
			[agent[t] setLaggedExpUtil00];
			[agent[t] setLaggedExpUtil01];
			[agent[t] setLaggedExpUtil10];
			[agent[t] setLaggedExpUtil11];
			[agent[t] setLaggedProbChooseOneGivenZero];
			[agent[t] setLaggedProbChooseOneGivenOne];
			cumulativeNumCorrectThisSim[t] = 0; // reset
			cumulativePropCorrectThisSim[t] = 0.0; // reset
			
			if (t == 0)
			{
				[agent[t] setPriorOneFirstAgent];
			}
			else
			{
				[agent[t] setPriorOneNotFirstAgent: agent[t-1]];
			}
			
			if ([agent[t] env] == 0)
			{
				sumPriorOneGivenZero[t] += [agent[t] priorOne]; // adding the agent's prior for the current simulation to sumPriorOneGivenZero[t]
			}
			else
			{
				sumPriorOneGivenOne[t] += [agent[t] priorOne]; // adding the agent's prior for the current simulation to sumPriorOneGivenOne[t]
			}
			
			[agent[t] setPrivateSignal];
			[agent[t] setPosteriorOne];
			[agent[t] setChoice];
			[agent[t] setChoiceCorrect];
			
			if (t == 0)
			{
				cumulativeNumCorrectThisSim[t] = [agent[t] choiceCorrect];
			}
			else // not the first position in the sequence
			{
				cumulativeNumCorrectThisSim[t] = cumulativeNumCorrectThisSim[t-1] + [agent[t] choiceCorrect];
			}
			
			cumulativePropCorrectThisSim[t] = (double) cumulativeNumCorrectThisSim[t] / (double) (t + 1);
			
			if ([agent[t] env] == 0)
			{
				sumChoiceCorrectGivenZero[t] += [agent[t] choiceCorrect];
				sumCumulativePropCorrectGivenZero[t] += cumulativePropCorrectThisSim[t];
			}
			else
			{
				sumChoiceCorrectGivenOne[t] += [agent[t] choiceCorrect];
				sumCumulativePropCorrectGivenOne[t] += cumulativePropCorrectThisSim[t];
			}
			
			if (finalPeriodData == 1 && t == (numAgents - 1))
			{
				fprintf(finalPeriodOutput,"%i	%i	%f	%i	%f	%i	%i\n", i, t,
						[agent[t] priorOne], [agent[t] privateSignal], [agent[t] posteriorOne], [agent[t] choice], [agent[t] env]);
			}
		}
		
		if (disaggData == 1)
		{
			for (t = 0; t < numAgents; t++)
			{
				fprintf(disaggOutput,"%i	%i	%f	%i	%f	%i	%i\n", i, t,
						[agent[t] priorOne], [agent[t] privateSignal], [agent[t] posteriorOne], [agent[t] choice], [agent[t] env]);
			}
		}
	}
	
	for (t = 0; t < numAgents; t++)
	{
		if (aggData == 1)
		{
			fprintf(aggOutput,"%i	%f	%f	%f	%f	%f	%f	%i	%i	%i\n", t,
				sumPriorOneGivenZero[t] / (double) sumEnvZero, sumPriorOneGivenOne[t] / (double) sumEnvOne,
				(double) sumChoiceCorrectGivenZero[t] / (double) sumEnvZero, (double) sumChoiceCorrectGivenOne[t] / (double) sumEnvOne, sumCumulativePropCorrectGivenZero[t] / (double) sumEnvZero, sumCumulativePropCorrectGivenOne[t] / (double) sumEnvOne, sumEnvZero, sumEnvOne, numSims);
		}
	}
	
	if (aggData == 1)
	{
		int fclose(FILE *aggOutput);	// close output file
	}
	
	if (disaggData == 1)
	{
		int fclose(FILE *disaggOutput);		// close output file
	}
	
	if (finalPeriodData == 1)
	{
		int fclose(FILE *finalPeriodOutput);		// close output file
	}
	
	// release agents
	for (t = 0; t < numAgents; t++)
	{
		[agent[t] release];
	}
	
	return 0;
}